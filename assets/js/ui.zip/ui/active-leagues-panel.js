(function () {
  if (!window.on || !window.emit) return;

  const listEl = document.getElementById("active-leagues-list");
  if (!listEl) return;

  function clear() {
    listEl.innerHTML = "";
  }

  function buildFromMatches(matches) {
    const map = {};
    matches.forEach(m => {
      if (!m.aimlLeagueId || !m.leagueName) return;
      if (!map[m.aimlLeagueId]) {
        map[m.aimlLeagueId] = {
          id: m.aimlLeagueId,
          leagueName: m.leagueName,
          count: 0
        };
      }
      map[m.aimlLeagueId].count++;
    });
    return Object.values(map).sort((a, b) => b.count - a.count);
  }

  function render(items) {
    clear();

    if (!items || items.length === 0) {
      const empty = document.createElement("div");
      empty.className = "list-empty";
      empty.textContent = "No active leagues today";
      listEl.appendChild(empty);
      return;
    }

    items.forEach(l => {
      const row = document.createElement("div");
      row.className = "league-row";

      const name = document.createElement("div");
      name.className = "league-name";
      name.textContent = l.leagueName;

      const badge = document.createElement("div");
      badge.className = "league-count";
      badge.textContent = l.count;

      row.appendChild(name);
      row.appendChild(badge);

      row.onclick = () => {
        window.emit("active-league-selected", {
          id: l.id,
          leagueName: l.leagueName
        });
      };

      listEl.appendChild(row);
    });
  }

  // 🔑 PRIMARY
  window.on("fixtures:loaded", payload => {
    const matches = Array.isArray(payload?.matches) ? payload.matches : [];
    render(buildFromMatches(matches));
  });

  // 🔑 FALLBACK (v7 snapshot flow)
  window.on("today-matches:loaded", payload => {
    const matches = Array.isArray(payload?.matches) ? payload.matches : [];
    render(buildFromMatches(matches));
  });

  clear();
})();
